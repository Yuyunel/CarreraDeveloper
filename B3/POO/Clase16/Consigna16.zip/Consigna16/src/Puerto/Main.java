package Puerto;

public class Main {
    public static void main(String[] args) {
        Puerto puerto = new Puerto("Buenos Aires");
        Contenedores cont1 =new Contenedores(12,"Colombia", true);
        Contenedores cont2 =new Contenedores(9,"Chile", true);
        Contenedores cont3 =new Contenedores(35,"Panama", true);

        puerto.addContenedor(cont1);
        puerto.addContenedor(cont2);
        puerto.addContenedor(cont3);

        puerto.mostrarContenedores();
    }
}
