package Puerto;

public class Contenedores implements Comparable<Contenedores> {
    private int nroIdentificacion;
    private String pais;
    private boolean marcaMP;

    public Contenedores(int nroIdentificacion, String pais, boolean marcaMP) {
        this.nroIdentificacion = nroIdentificacion;
        this.pais = pais;
        this.marcaMP = marcaMP;
    }

    @Override
    public int compareTo(Contenedores o) {
        return this.getNroIdentificacion()- o.getNroIdentificacion();
    }

    public int getNroIdentificacion() {
        return nroIdentificacion;
    }

    public void setNroIdentificacion(int nroIdentificacion) {
        this.nroIdentificacion = nroIdentificacion;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public boolean isMarcaMP() {
        return marcaMP;
    }

    public void setMarcaMP(boolean marcaMP) {
        this.marcaMP = marcaMP;
    }
}
