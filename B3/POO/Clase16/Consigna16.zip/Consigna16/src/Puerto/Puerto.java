package Puerto;

import java.util.List;
import java.util.jar.JarEntry;

public class Puerto {
    private String nombre;
    private List<Contenedores> contenedores;

    public Puerto(String nombre) {
        this.nombre = nombre;
    }

    public void addContenedor(Contenedores contenedores){
        this.contenedores.add(contenedores);
        System.out.println("Contenedor agregado"
                + contenedores.getNroIdentificacion()+ "del pais"
                +contenedores.getPais() + this.getNombre());

    }
    public void mostrarContenedores(){
        contenedores.sort(null);
        for(Contenedores contenedores: this.contenedores){
            if(contenedores.isMarcaMP()){
                System.out.println(contenedores.getPais());
            }
        }

    }
    public int getCantidadContenedores(){
        int cantContenedores = 0;
        for(Contenedores contenedores: this.contenedores){
            if(contenedores.isMarcaMP()){
                cantContenedores++;
            }
        }

        return cantContenedores;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
