package com.company;

public class Rectangulo implements Figura{
    private Double alto;
    private Double largo;

    public Rectangulo(Double alto, Double largo) {
        this.alto = alto;
        this.largo = largo;
    }

    @Override
    public String mostrarDatos() {
        return "Rectangulo de "+ getAlto()+" de alto, "+ getLargo()+ " de largo y area "+ calcularArea();
    }

    @Override
    public double calcularArea() {
        return alto*largo;
    }

    public Double getAlto() {
        return alto;
    }

    public void setAlto(Double alto) {
        this.alto = alto;
    }

    public Double getLargo() {
        return largo;
    }

    public void setLargo(Double largo) {
        this.largo = largo;
    }
}
