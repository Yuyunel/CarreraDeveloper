package com.company;

import java.io.FileOutputStream;

public class Main {

    public static void main(String[] args) {
        FiguraCompuesta vagon= new FiguraCompuesta();
        vagon.agregarFigura(new Rectangulo(5.,4.));
        vagon.agregarFigura(new Circulo(1.));
        vagon.agregarFigura(new Circulo(1.));
        vagon.agregarFigura(new Circulo(1.));
        System.out.println("Area de la figura: " + vagon.calcularArea());;



    }
}
