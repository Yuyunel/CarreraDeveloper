package com.company;

public class Circulo implements Figura{
    private Double radio;
    //private final Double PI=Math.PI;

    public Circulo(Double radio) {
        this.radio = radio;
    }

    @Override
    public String mostrarDatos() {
        return "Circulo de "+ getRadio()+" de radio y area " + calcularArea();
    }

    @Override
    public double calcularArea() {
        return (radio*radio)*Math.PI;
    }

    public Double getRadio() {
        return radio;
    }

    public void setRadio(Double radio) {
        this.radio = radio;
    }
}
