package com.company;
import java.util.ArrayList;
import java.util.List;

public class FiguraCompuesta implements Figura{
    private List<Figura> figuras;

    public FiguraCompuesta() {
        this.figuras = new ArrayList<>();
    }

    public void agregarFigura(Figura f){
        this.figuras.add(f);
    }

    @Override
    public String mostrarDatos() {
        String datos="";
        for(Figura f: figuras){
            datos+= f.mostrarDatos()+"\n";
        }
        return datos;
    }

    @Override
    public double calcularArea() {
        double areaTotal=0.;
        for(Figura f : figuras){
           areaTotal+=f.calcularArea();
        }
        return areaTotal;
    }
}
