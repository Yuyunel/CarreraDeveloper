package com.company;

public interface Figura {
    String mostrarDatos();
    double calcularArea();
}
