package presencial;

import java.util.ArrayList;
import java.util.List;

public class Combo extends Item{
    private List<Item> items;

    public Combo(String nombre) {
        super(nombre);
        items= new ArrayList();
    }

    public void agregarItem(Item i){
        items.add(i);
    }

    @Override
    public double calcularPrecio() {
        double total=0;
        for (Item i:items) {
            total+=i.calcularPrecio();
        }
        return total*0.9;
    }

    @Override
    public String mostrarDatos() {
        String texto=getNombre()+"--> "+calcularPrecio()+"\n";
        for (Item i:items) {
            texto=texto.concat(i.mostrarDatos()+"\n");
        }
        return texto;
    }
}
