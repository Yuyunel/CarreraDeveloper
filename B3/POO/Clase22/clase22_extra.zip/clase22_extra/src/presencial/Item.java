package presencial;

public abstract class Item {
    private String nombre;

    public abstract double calcularPrecio();
    public abstract String mostrarDatos();

    public Item(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
