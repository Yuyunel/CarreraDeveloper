package presencial;

public class Main {
    public static void main(String[] args) {

        Combo c1=new Combo("Pack preferiado");

        c1.agregarItem(new Comida("Papas Fritas",400));
        c1.agregarItem(new Comida("Gaseosa",300));

        Comida d1= new Comida("Flan",200);

        System.out.println(c1.mostrarDatos());
        System.out.println("------");
        System.out.println(d1.mostrarDatos());

    }
}
