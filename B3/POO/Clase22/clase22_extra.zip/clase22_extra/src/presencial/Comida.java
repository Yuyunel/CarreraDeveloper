package presencial;

public class Comida extends Item{
    private double precio;

    public Comida(String nombre, double precio) {
        super(nombre);
        this.precio=precio;
    }

    @Override
    public double calcularPrecio() {
        return precio;
    }

    @Override
    public String mostrarDatos() {
        return getNombre()+"--> Precio: "+precio;
    }
}
