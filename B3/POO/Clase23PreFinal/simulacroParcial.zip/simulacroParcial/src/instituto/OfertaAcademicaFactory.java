package instituto;

public class OfertaAcademicaFactory {
    public static OfertaAcademicaFactory instance;
    public static final String CODIGO_CURSO = "CURSO";
    public static final String CODIGO_INTENSIVO = "INTENSIVO";

    public static OfertaAcademicaFactory getInstance() {
        if (instance == null) {
            instance = new OfertaAcademicaFactory();
        }
        return instance;
    }

    public OfertaAcademica crearOfertaAcademica
            (String codigo, String nombre, String descripcion)
            throws Exception {
            switch (codigo) {
                case OfertaAcademicaFactory.CODIGO_CURSO:
                    return new Curso(nombre, descripcion);
                case OfertaAcademicaFactory.CODIGO_INTENSIVO:
                    return new ProgramaIntensivo(nombre, descripcion);
                default: {
                    throw new Exception("El codigo ingresado es incorrecto");
                }

            }
    }

}
