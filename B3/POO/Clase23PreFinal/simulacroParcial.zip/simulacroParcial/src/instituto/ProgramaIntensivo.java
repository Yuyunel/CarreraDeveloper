package instituto;

import java.util.ArrayList;
import java.util.List;

public class ProgramaIntensivo extends OfertaAcademica{
    private double porcentajeDescuento = 0;
    private List<OfertaAcademica> ofertasAcademicas;

    public ProgramaIntensivo(String nombre, String descripcion) {
        super(nombre, descripcion);
        this.ofertasAcademicas = new ArrayList<>();
    }

    public ProgramaIntensivo(String nombre, String descripcion, double porcentajeDescuento) {
        super(nombre, descripcion);
        this.porcentajeDescuento = porcentajeDescuento;
        this.ofertasAcademicas = new ArrayList<>();
    }

    @Override
    public double calcularPrecio() throws Exception {
        if(ofertasAcademicas.size()<=0) {
            throw new Exception("Para calcular el precio, debe agregar cursos.");
        } else if(porcentajeDescuento == 0) {
            throw new Exception("Para calcular el precio, debe agregar el descuento.");
        }
        double precioFinal = 0;
        for(OfertaAcademica o : ofertasAcademicas) {
            precioFinal += o.calcularPrecio();
        }
        double descuento = precioFinal * porcentajeDescuento /100;
        return precioFinal - descuento ;
    }

    public void agregarCurso(OfertaAcademica o) {
        this.ofertasAcademicas.add(o);
    }

    public double getPorcentajeDescuento() {
        return porcentajeDescuento;
    }

    public void setPorcentajeDescuento(double porcentajeDescuento) {
        this.porcentajeDescuento = porcentajeDescuento;
    }

    public List<OfertaAcademica> getOfertasAcademicas() {
        return ofertasAcademicas;
    }

    public void setOfertasAcademicas(List<OfertaAcademica> ofertasAcademicas) {
        this.ofertasAcademicas = ofertasAcademicas;
    }
}
