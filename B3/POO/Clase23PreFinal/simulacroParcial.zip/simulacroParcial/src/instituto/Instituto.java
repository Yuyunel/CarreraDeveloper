package instituto;

public class Instituto {
    private String nombre;

    public Instituto(String nombre) {
        this.nombre = nombre;
    }

    public void crearPaquete() {

    }

    public void generarInforme() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
