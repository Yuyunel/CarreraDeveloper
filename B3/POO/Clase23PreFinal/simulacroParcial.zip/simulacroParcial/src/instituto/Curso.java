package instituto;

public class Curso extends OfertaAcademica {
    private double cantidadHoras;
    private int cantidadMeses;
    private double precioHora;

    public Curso(String nombre, String descripcion) {
        super(nombre, descripcion);
    }

    public Curso(String nombre, String descripcion, double cantidadHoras, int cantidadMeses, double precioHora) {
        super(nombre, descripcion);
        this.cantidadHoras = cantidadHoras;
        this.cantidadMeses = cantidadMeses;
        this.precioHora = precioHora;
    }

    @Override
    public double calcularPrecio() {
        return cantidadHoras * cantidadMeses * precioHora;
    }

    public double getCantidadHoras() {
        return cantidadHoras;
    }

    public void setCantidadHoras(double cantidadHoras) {
        this.cantidadHoras = cantidadHoras;
    }

    public int getCantidadMeses() {
        return cantidadMeses;
    }

    public void setCantidadMeses(int cantidadMeses) {
        this.cantidadMeses = cantidadMeses;
    }

    public double getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(double precioHora) {
        this.precioHora = precioHora;
    }
}
