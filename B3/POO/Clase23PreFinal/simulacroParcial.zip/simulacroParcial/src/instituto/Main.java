package instituto;

public class Main {
    public static void main(String[] args) throws Exception {
        OfertaAcademica frontend =
                OfertaAcademicaFactory.getInstance().crearOfertaAcademica(OfertaAcademicaFactory.CODIGO_CURSO,
                        "frontend", "curso frontend");
        OfertaAcademica backend =
                OfertaAcademicaFactory.getInstance().crearOfertaAcademica(OfertaAcademicaFactory.CODIGO_CURSO,
                        "backend", "curso backend");
        OfertaAcademica fullStack =
                OfertaAcademicaFactory.getInstance().crearOfertaAcademica(OfertaAcademicaFactory.CODIGO_INTENSIVO,
                "fullstack", "curso fullstack");

        ((Curso)frontend).setCantidadHoras(16);
        ((Curso)frontend).setPrecioHora(1000);
        ((Curso)frontend).setCantidadMeses(2);

        ((Curso)backend).setCantidadHoras(20);
        ((Curso)backend).setPrecioHora(900);
        ((Curso)backend).setCantidadMeses(2);

        ((ProgramaIntensivo)fullStack).agregarCurso(frontend);
        ((ProgramaIntensivo)fullStack).agregarCurso(backend);

        ((ProgramaIntensivo)fullStack).setPorcentajeDescuento(20);

        System.out.println(((ProgramaIntensivo)fullStack).calcularPrecio());
    }
}
