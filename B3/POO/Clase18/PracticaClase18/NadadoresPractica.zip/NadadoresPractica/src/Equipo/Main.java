package Equipo;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Equipo equipo= new Equipo("Poderosas");

        equipo.agregarNadadores(new Nadador("Acevedo","PRINCIPIANTE",9));
        equipo.agregarNadadores(new Nadador("Morales","PROFESIONAL",11));
        equipo.agregarNadadores(new Nadador("Coral","EXPERTO",14));
        equipo.agregarNadadores(new Nadador("Gomez","INTERMEDIO",8));
        equipo.agregarNadadores(new Nadador("Mendez","PRINCIPIANTE",5));
        equipo.agregarNadadores(new Nadador("Diaz","EXPERTO",7));
        equipo.agregarNadadores(new Nadador("Lopez","PRINCIPIANTE",13));

            // para obtener nivel
        ArrayList<Nadador> nadadoresNivel= equipo.obtenerNivel();
        System.out.println("Lista de Nadadores obtenidos ");
        for (Nadador nadador: nadadoresNivel)
            System.out.println(nadador.getApellido());

        // obtener Cantidad Nadadores y llamar la execepcion

        try {
            System.out.println(" La cantidad Nadadores en el nivel principiante es : "+ equipo.cantNadadores("PRINCIPIANTE"));
        }catch (Exception e){
            e.printStackTrace();
        }
        //


    }
}
