package Equipo;

import java.util.ArrayList;

public class Equipo {
    private String nombre;
    private ArrayList<Nadador> nadadores;


    public Equipo(String nombre) {
        this.nombre = nombre;
        this.nadadores = new ArrayList<>();
    }
    public void agregarNadadores(Nadador nadador){
        this.nadadores.add(nadador);
    }
    public ArrayList<Nadador>obtenerNivel(){
        ArrayList<Nadador> nivel = new ArrayList<>();
        for(int contador = this.nadadores.size()-1;contador  >= nadadores.size() -2; contador--){
            nivel.add(nadadores.get(contador)) ;
        }
        return nivel;
    }
    public int cantNadadores( String nivel)throws Exception{
        int cont = 0;
        if(nivel.equals("PRINCIPIANTE")|| nivel.equals("INTERMEDIO")|| nivel.equals("EXPERTO")|| nivel.equals("PROFESIONAL")){
            for (Nadador nadador:nadadores) {
                if(nadador.getNivel().equals(nivel)){
                    cont++;

                }

            }

            }else{
            throw new Exception("El nivel "+nivel+ "no es valido");
        }
        return cont;
        }

    }


