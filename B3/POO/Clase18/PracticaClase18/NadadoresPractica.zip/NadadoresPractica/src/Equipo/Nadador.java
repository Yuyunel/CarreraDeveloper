package Equipo;

public class Nadador {
    private String apellido;
    private String nivel;
    private int nroCamiseta;

    public Nadador(String apellido, String nivel, int nroCamiseta) {
        this.apellido = apellido;
        this.nivel = nivel;
        this.nroCamiseta = nroCamiseta;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public int getNroCamiseta() {
        return nroCamiseta;
    }

    public void setNroCamiseta(int nroCamiseta) {
        this.nroCamiseta = nroCamiseta;
    }
}
