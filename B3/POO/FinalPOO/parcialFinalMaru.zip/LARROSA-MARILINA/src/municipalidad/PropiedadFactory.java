package municipalidad;

public class PropiedadFactory {
    public static PropiedadFactory instance;
    public static final String COD_CASA = "CASA";
    public static final String COD_BARRIO = "BARRIO";

    public static PropiedadFactory getInstance() {
        if(instance == null) {
            instance = new PropiedadFactory();
        }
        return instance;
    }

    public Propiedad crearPropiedad(String codigo, String c, int n) throws Exception {
        switch (codigo) {
            case PropiedadFactory.COD_CASA:
                return new Casa(c, n);
            case PropiedadFactory.COD_BARRIO:
                return new BarrioCerrado(c, n);
            default:
                throw new Exception("El codigo no es valido");
        }
    }
}
