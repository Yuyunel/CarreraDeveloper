package municipalidad;

import java.util.ArrayList;
import java.util.List;

public class BarrioCerrado extends Propiedad {
    private int factorMultiplicador;
    private List<Propiedad> propiedades;

    public BarrioCerrado(String calle, int numero) {
        super(calle, numero);
        this.propiedades = new ArrayList<>();
    }

    public BarrioCerrado(String calle, int numero, int factorMultiplicador) {
        super(calle, numero);
        this.factorMultiplicador = factorMultiplicador;
        this.propiedades = new ArrayList<>();
    }

    @Override
    public double calcularImpuesto() throws Exception {
        if (this.propiedades.size() <= 0) {
            throw new Exception("El barrio no cuenta con ninguna propiedad");
        } else if (this.factorMultiplicador <= 0) {
            throw new Exception("Debe ingresar el factor multiplicador primero");
        } else {
            double impuestoTotal = 0;
            for (Propiedad propiedad : this.propiedades) {
                impuestoTotal += propiedad.calcularImpuesto();
            }
            return (impuestoTotal * this.factorMultiplicador);
        }
    }

    public void agregarCasa(Propiedad casa) throws Exception{
        try {
            this.propiedades.add(casa);
        } catch (Exception e) {
            throw new Exception("Ocurrio un error al intentar agregar la propiedad. Intente nuevamente");
        }
    }

    public int getFactorMultiplicador() {
        return factorMultiplicador;
    }

    public void setFactorMultiplicador(int factorMultiplicador) {
        this.factorMultiplicador = factorMultiplicador;
    }

    public List<Propiedad> getPropiedades() {
        return propiedades;
    }

    public void setPropiedades(List<Propiedad> propiedades) {
        this.propiedades = propiedades;
    }

    public int getCantidadPropiedades() {
        return this.propiedades.size();
    }
}
