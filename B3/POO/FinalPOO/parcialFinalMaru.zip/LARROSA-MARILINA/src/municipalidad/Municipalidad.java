package municipalidad;

import java.util.ArrayList;
import java.util.List;

public class Municipalidad {
    private String localidad;
    private List<Propiedad> propiedades;

    public Municipalidad(String localidad) {
        this.localidad = localidad;
        this.propiedades = new ArrayList<>();
    }

    public void agregarPropiedad(Propiedad propiedad) throws Exception {
        try {
            this.propiedades.add(propiedad);
        } catch (Exception e) {
            throw new Exception("Ocurrio un error al intentar agregar la propiedad. Intente nuevamente");
        }
    }

    public void mostrarPropiedades() throws Exception {
        if (this.propiedades.size() <= 0) {
            throw new Exception("La municipalidad no tiene ninguna propiedad");
        } else {
            for (Propiedad propiedad : this.propiedades) {
                    System.out.println(
                        "La propiedad de la calle " + propiedad.getCalle() + " "
                                + propiedad.getNumero() + " tiene un impuesto de " + propiedad.calcularImpuesto());
                }
            }
        }
}
