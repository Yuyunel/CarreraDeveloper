package municipalidad;

public class Casa extends Propiedad{
    private double impuestoBase;

    public Casa(String calle, int numero) {
        super(calle, numero);
    }

    public Casa(String calle, int numero, double impuestoBase) {
        super(calle, numero);
        this.impuestoBase = impuestoBase;
    }

    private boolean faltanDatos() {
        if (this.getCalle() == null || getCalle().equals("") || this.getNumero() <= 0) {
            return true;
        }
        return false;
    }

    @Override
    public double calcularImpuesto() throws Exception {
        if(this.faltanDatos()) {
            throw new Exception("Faltan datos de la propiedad");
        } else if (this.impuestoBase <= 0) {
            throw new Exception("Debe fijar un impuesto base para la propiedad de la calle " + this.getCalle() + " " + this.getNumero());
        } else {
            if (this.getCalle().contains("Av. San Martin")){
                return this.impuestoBase * 1.1;
            }
            return this.impuestoBase;
        }
    }

    public double getImpuestoBase() {
        return impuestoBase;
    }

    public void setImpuestoBase(double impuestoBase) {
        this.impuestoBase = impuestoBase;
    }
}
