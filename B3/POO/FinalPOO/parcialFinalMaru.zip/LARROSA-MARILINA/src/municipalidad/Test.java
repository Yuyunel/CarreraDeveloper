package municipalidad;

public class Test {
    public static void main(String[] args) throws Exception {
        Propiedad casaSanMartin = PropiedadFactory.getInstance().crearPropiedad(PropiedadFactory.COD_CASA, "Av. San Martin",
                130);
        ((Casa)casaSanMartin).setImpuestoBase(500);
        Propiedad casaMitre = PropiedadFactory.getInstance().crearPropiedad(PropiedadFactory.COD_CASA, "Mitre",
                233);
        ((Casa)casaMitre).setImpuestoBase(700);
        Propiedad casa9Julio = PropiedadFactory.getInstance().crearPropiedad(PropiedadFactory.COD_CASA, "Av. 9 de " +
                        "julio",
                450);
        ((Casa)casa9Julio).setImpuestoBase(600);

        Propiedad barrioGutierres = PropiedadFactory.getInstance().crearPropiedad(PropiedadFactory.COD_BARRIO,
                "Gutierres", 423);
        ((BarrioCerrado)barrioGutierres).setFactorMultiplicador(2);

        ((BarrioCerrado) barrioGutierres).agregarCasa(casaSanMartin);
        ((BarrioCerrado) barrioGutierres).agregarCasa(casaMitre);
        System.out.println(barrioGutierres.calcularImpuesto());

        Municipalidad lanus = new Municipalidad("Lanus");
        lanus.agregarPropiedad(casa9Julio);
        lanus.agregarPropiedad(barrioGutierres);
        lanus.mostrarPropiedades();

    }
}
