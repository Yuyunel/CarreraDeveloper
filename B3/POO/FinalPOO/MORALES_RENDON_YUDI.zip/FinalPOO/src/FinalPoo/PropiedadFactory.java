package FinalPoo;

public class PropiedadFactory {

    public static PropiedadFactory  instance;
    public static final String AVENIDA_SAN_MARTIN = "AV. San Martín";
    public static final String MITRE = "Mitre";
    public static final String BARRIOCERRADO = "Gutierres";


    private PropiedadFactory(){}
    public static PropiedadFactory getInstance(){
        if(instance == null){
            instance =new PropiedadFactory();
        }
        return  instance;
    }
    public Propiedad crearPropiedad(String p){
        switch (p){
            case AVENIDA_SAN_MARTIN:
                return new Casas("Av San Martin", 130,500.);
            case MITRE:
                return new Casas("Mitre",233,700.);
            case BARRIOCERRADO:
                BarrioCerrado barrioCerrado= new BarrioCerrado(BARRIOCERRADO,330,2);
                barrioCerrado.agregarPropiedad(AVENIDA_SAN_MARTIN);
                barrioCerrado.agregarPropiedad(MITRE);
                return barrioCerrado;
            default:
                return null;
        }

    }


}
