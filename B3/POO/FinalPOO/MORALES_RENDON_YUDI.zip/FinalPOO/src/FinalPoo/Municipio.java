package FinalPoo;

import java.util.ArrayList;
import java.util.List;

public class Municipio {
    private List<Propiedad> propiedads;

    public Municipio(){
        propiedads = new ArrayList<>();
    }

    public void mostrarPropiedad(){
        for (Propiedad propiedad: propiedads) {
            System.out.println(propiedad);

        }

    }

    public void agregarPropiedad(String propiedad){
        propiedads.add(PropiedadFactory.getInstance().crearPropiedad(propiedad));

    }


}
