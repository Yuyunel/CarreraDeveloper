package FinalPoo;

public class Main {
    public static void main(String[] args) {
        Municipio municipio = new Municipio();
        PropiedadFactory propiedadFactory = PropiedadFactory.getInstance();


        municipio.agregarPropiedad(propiedadFactory.AVENIDA_SAN_MARTIN);
        municipio.agregarPropiedad(propiedadFactory.MITRE);
        municipio.agregarPropiedad(propiedadFactory.BARRIOCERRADO);

        municipio.mostrarPropiedad();




    }
}
