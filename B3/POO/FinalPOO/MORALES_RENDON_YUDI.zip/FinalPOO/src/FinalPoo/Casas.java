package FinalPoo;

public class Casas extends Propiedad{

    private Double montoBaseImpuesto;

    public Casas(String calle, int numero, Double montoBaseImpuesto) {
        super(calle, numero);
        this.montoBaseImpuesto=montoBaseImpuesto;
    }

    public Double getMontoBaseImpuesto() {
        return montoBaseImpuesto;
    }

    public void setMontoBaseImpuesto(Double montoBaseImpuesto) {
        this.montoBaseImpuesto = montoBaseImpuesto;
    }

    @Override
    public Double calcularIpuesto() {
        if(getCalle().equals("Av. San Martín")){
            return montoBaseImpuesto + (montoBaseImpuesto * 0.1);
        }
        return montoBaseImpuesto;

    }

}
