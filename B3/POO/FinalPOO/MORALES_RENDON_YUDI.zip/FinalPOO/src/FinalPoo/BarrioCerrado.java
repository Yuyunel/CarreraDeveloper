package FinalPoo;

import java.util.ArrayList;
import java.util.List;

public class BarrioCerrado extends Propiedad{

    private int factorMultiplicador;
    private List<Propiedad> propiedads;

    public BarrioCerrado(String calle, int numero, int factorMultiplicador ) {
        super(calle, numero);
        this.factorMultiplicador = factorMultiplicador;
        propiedads = new ArrayList<>();
    }


    public void agregarPropiedad(String p){
        propiedads.add(PropiedadFactory.getInstance().crearPropiedad(p));

    }

    public int getFactorMultiplicador() {
        return factorMultiplicador;
    }

    public void setFactorMultiplicador(int factorMultiplicador) {
        this.factorMultiplicador = factorMultiplicador;
    }

    @Override
    public Double calcularIpuesto() {
        Double totalImpuestos = 0.;
        for (Propiedad propiedad: propiedads) {
            totalImpuestos += propiedad.calcularIpuesto();
        }
        return totalImpuestos * factorMultiplicador;
    }
}
